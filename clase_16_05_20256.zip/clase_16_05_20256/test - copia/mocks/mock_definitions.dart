import 'package:mockito/annotations.dart';
import 'package:mi_app_pruebas/services/auth_service.dart';

@GenerateMocks([AuthService])
void main() {}
